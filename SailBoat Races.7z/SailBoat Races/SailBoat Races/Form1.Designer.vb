﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtB1R2 = New System.Windows.Forms.TextBox()
        Me.txtB1R3 = New System.Windows.Forms.TextBox()
        Me.txtB1R4 = New System.Windows.Forms.TextBox()
        Me.txtB2R1 = New System.Windows.Forms.TextBox()
        Me.txtB2R2 = New System.Windows.Forms.TextBox()
        Me.txtB2R3 = New System.Windows.Forms.TextBox()
        Me.txtB2R4 = New System.Windows.Forms.TextBox()
        Me.txtB3R1 = New System.Windows.Forms.TextBox()
        Me.txtB3R2 = New System.Windows.Forms.TextBox()
        Me.txtB3R3 = New System.Windows.Forms.TextBox()
        Me.txtB3R4 = New System.Windows.Forms.TextBox()
        Me.lblB1Total = New System.Windows.Forms.Label()
        Me.lblB1Rank = New System.Windows.Forms.Label()
        Me.lblB2Total = New System.Windows.Forms.Label()
        Me.lblB2Rank = New System.Windows.Forms.Label()
        Me.lblB3Total = New System.Windows.Forms.Label()
        Me.lblB3Rank = New System.Windows.Forms.Label()
        Me.btnCalculate = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.txtB1R1 = New System.Windows.Forms.TextBox()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.lblStatus = New System.Windows.Forms.ToolStripStatusLabel()
        Me.GroupBox1.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.lblB3Rank)
        Me.GroupBox1.Controls.Add(Me.lblB3Total)
        Me.GroupBox1.Controls.Add(Me.lblB2Rank)
        Me.GroupBox1.Controls.Add(Me.lblB2Total)
        Me.GroupBox1.Controls.Add(Me.lblB1Rank)
        Me.GroupBox1.Controls.Add(Me.lblB1Total)
        Me.GroupBox1.Controls.Add(Me.txtB3R4)
        Me.GroupBox1.Controls.Add(Me.txtB3R3)
        Me.GroupBox1.Controls.Add(Me.txtB3R2)
        Me.GroupBox1.Controls.Add(Me.txtB3R1)
        Me.GroupBox1.Controls.Add(Me.txtB2R4)
        Me.GroupBox1.Controls.Add(Me.txtB2R3)
        Me.GroupBox1.Controls.Add(Me.txtB2R2)
        Me.GroupBox1.Controls.Add(Me.txtB2R1)
        Me.GroupBox1.Controls.Add(Me.txtB1R4)
        Me.GroupBox1.Controls.Add(Me.txtB1R3)
        Me.GroupBox1.Controls.Add(Me.txtB1R2)
        Me.GroupBox1.Controls.Add(Me.txtB1R1)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Location = New System.Drawing.Point(80, 87)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(632, 301)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Race Results"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(149, 51)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(42, 13)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Race 1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(219, 51)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(42, 13)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Race 2"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(300, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(42, 13)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "Race 3"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(383, 51)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(42, 13)
        Me.Label4.TabIndex = 3
        Me.Label4.Text = "Race 4"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(481, 51)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(31, 13)
        Me.Label5.TabIndex = 4
        Me.Label5.Text = "Total"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(549, 51)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(33, 13)
        Me.Label6.TabIndex = 5
        Me.Label6.Text = "Rank"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(58, 107)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(48, 13)
        Me.Label7.TabIndex = 6
        Me.Label7.Text = "Boat # 1"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(58, 173)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(48, 13)
        Me.Label8.TabIndex = 7
        Me.Label8.Text = "Boat # 2"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(58, 235)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(48, 13)
        Me.Label9.TabIndex = 8
        Me.Label9.Text = "Boat # 3"
        '
        'txtB1R2
        '
        Me.txtB1R2.Location = New System.Drawing.Point(222, 100)
        Me.txtB1R2.Name = "txtB1R2"
        Me.txtB1R2.Size = New System.Drawing.Size(54, 20)
        Me.txtB1R2.TabIndex = 4
        '
        'txtB1R3
        '
        Me.txtB1R3.Location = New System.Drawing.Point(288, 100)
        Me.txtB1R3.Name = "txtB1R3"
        Me.txtB1R3.Size = New System.Drawing.Size(54, 20)
        Me.txtB1R3.TabIndex = 7
        '
        'txtB1R4
        '
        Me.txtB1R4.Location = New System.Drawing.Point(371, 100)
        Me.txtB1R4.Name = "txtB1R4"
        Me.txtB1R4.Size = New System.Drawing.Size(54, 20)
        Me.txtB1R4.TabIndex = 10
        '
        'txtB2R1
        '
        Me.txtB2R1.Location = New System.Drawing.Point(152, 166)
        Me.txtB2R1.Name = "txtB2R1"
        Me.txtB2R1.Size = New System.Drawing.Size(54, 20)
        Me.txtB2R1.TabIndex = 2
        '
        'txtB2R2
        '
        Me.txtB2R2.Location = New System.Drawing.Point(222, 166)
        Me.txtB2R2.Name = "txtB2R2"
        Me.txtB2R2.Size = New System.Drawing.Size(54, 20)
        Me.txtB2R2.TabIndex = 5
        '
        'txtB2R3
        '
        Me.txtB2R3.Location = New System.Drawing.Point(288, 164)
        Me.txtB2R3.Name = "txtB2R3"
        Me.txtB2R3.Size = New System.Drawing.Size(54, 20)
        Me.txtB2R3.TabIndex = 8
        '
        'txtB2R4
        '
        Me.txtB2R4.Location = New System.Drawing.Point(371, 166)
        Me.txtB2R4.Name = "txtB2R4"
        Me.txtB2R4.Size = New System.Drawing.Size(54, 20)
        Me.txtB2R4.TabIndex = 11
        '
        'txtB3R1
        '
        Me.txtB3R1.Location = New System.Drawing.Point(152, 228)
        Me.txtB3R1.Name = "txtB3R1"
        Me.txtB3R1.Size = New System.Drawing.Size(54, 20)
        Me.txtB3R1.TabIndex = 3
        '
        'txtB3R2
        '
        Me.txtB3R2.Location = New System.Drawing.Point(222, 228)
        Me.txtB3R2.Name = "txtB3R2"
        Me.txtB3R2.Size = New System.Drawing.Size(54, 20)
        Me.txtB3R2.TabIndex = 6
        '
        'txtB3R3
        '
        Me.txtB3R3.Location = New System.Drawing.Point(288, 228)
        Me.txtB3R3.Name = "txtB3R3"
        Me.txtB3R3.Size = New System.Drawing.Size(54, 20)
        Me.txtB3R3.TabIndex = 9
        '
        'txtB3R4
        '
        Me.txtB3R4.Location = New System.Drawing.Point(371, 228)
        Me.txtB3R4.Name = "txtB3R4"
        Me.txtB3R4.Size = New System.Drawing.Size(54, 20)
        Me.txtB3R4.TabIndex = 12
        '
        'lblB1Total
        '
        Me.lblB1Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblB1Total.Location = New System.Drawing.Point(458, 97)
        Me.lblB1Total.Name = "lblB1Total"
        Me.lblB1Total.Size = New System.Drawing.Size(54, 22)
        Me.lblB1Total.TabIndex = 21
        '
        'lblB1Rank
        '
        Me.lblB1Rank.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblB1Rank.Location = New System.Drawing.Point(537, 97)
        Me.lblB1Rank.Name = "lblB1Rank"
        Me.lblB1Rank.Size = New System.Drawing.Size(54, 22)
        Me.lblB1Rank.TabIndex = 22
        '
        'lblB2Total
        '
        Me.lblB2Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblB2Total.Location = New System.Drawing.Point(458, 166)
        Me.lblB2Total.Name = "lblB2Total"
        Me.lblB2Total.Size = New System.Drawing.Size(54, 22)
        Me.lblB2Total.TabIndex = 23
        '
        'lblB2Rank
        '
        Me.lblB2Rank.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblB2Rank.Location = New System.Drawing.Point(528, 166)
        Me.lblB2Rank.Name = "lblB2Rank"
        Me.lblB2Rank.Size = New System.Drawing.Size(54, 22)
        Me.lblB2Rank.TabIndex = 24
        '
        'lblB3Total
        '
        Me.lblB3Total.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblB3Total.Location = New System.Drawing.Point(458, 230)
        Me.lblB3Total.Name = "lblB3Total"
        Me.lblB3Total.Size = New System.Drawing.Size(54, 22)
        Me.lblB3Total.TabIndex = 25
        '
        'lblB3Rank
        '
        Me.lblB3Rank.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblB3Rank.Location = New System.Drawing.Point(528, 230)
        Me.lblB3Rank.Name = "lblB3Rank"
        Me.lblB3Rank.Size = New System.Drawing.Size(54, 22)
        Me.lblB3Rank.TabIndex = 26
        '
        'btnCalculate
        '
        Me.btnCalculate.Location = New System.Drawing.Point(84, 424)
        Me.btnCalculate.Name = "btnCalculate"
        Me.btnCalculate.Size = New System.Drawing.Size(186, 27)
        Me.btnCalculate.TabIndex = 1
        Me.btnCalculate.Text = "Calculate Totals"
        Me.btnCalculate.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(343, 424)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(179, 26)
        Me.btnClear.TabIndex = 2
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(578, 428)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(75, 23)
        Me.btnClose.TabIndex = 3
        Me.btnClose.Text = "Close"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'txtB1R1
        '
        Me.txtB1R1.Location = New System.Drawing.Point(152, 100)
        Me.txtB1R1.Name = "txtB1R1"
        Me.txtB1R1.Size = New System.Drawing.Size(54, 20)
        Me.txtB1R1.TabIndex = 1
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.lblStatus})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 545)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Size = New System.Drawing.Size(861, 22)
        Me.StatusStrip1.TabIndex = 4
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'lblStatus
        '
        Me.lblStatus.Name = "lblStatus"
        Me.lblStatus.Size = New System.Drawing.Size(0, 17)
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(861, 567)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCalculate)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtB3R4 As System.Windows.Forms.TextBox
    Friend WithEvents txtB3R3 As System.Windows.Forms.TextBox
    Friend WithEvents txtB3R2 As System.Windows.Forms.TextBox
    Friend WithEvents txtB3R1 As System.Windows.Forms.TextBox
    Friend WithEvents txtB2R4 As System.Windows.Forms.TextBox
    Friend WithEvents txtB2R3 As System.Windows.Forms.TextBox
    Friend WithEvents txtB2R2 As System.Windows.Forms.TextBox
    Friend WithEvents txtB2R1 As System.Windows.Forms.TextBox
    Friend WithEvents txtB1R4 As System.Windows.Forms.TextBox
    Friend WithEvents txtB1R3 As System.Windows.Forms.TextBox
    Friend WithEvents txtB1R2 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblB3Rank As System.Windows.Forms.Label
    Friend WithEvents lblB3Total As System.Windows.Forms.Label
    Friend WithEvents lblB2Rank As System.Windows.Forms.Label
    Friend WithEvents lblB2Total As System.Windows.Forms.Label
    Friend WithEvents lblB1Rank As System.Windows.Forms.Label
    Friend WithEvents lblB1Total As System.Windows.Forms.Label
    Friend WithEvents btnCalculate As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents txtB1R1 As System.Windows.Forms.TextBox
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents lblStatus As System.Windows.Forms.ToolStripStatusLabel

End Class
