﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.lblCancel = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblTotal = New System.Windows.Forms.Label()
        Me.btn11 = New System.Windows.Forms.Button()
        Me.btn12 = New System.Windows.Forms.Button()
        Me.btn13 = New System.Windows.Forms.Button()
        Me.btn14 = New System.Windows.Forms.Button()
        Me.btn15 = New System.Windows.Forms.Button()
        Me.btn21 = New System.Windows.Forms.Button()
        Me.btn22 = New System.Windows.Forms.Button()
        Me.btn23 = New System.Windows.Forms.Button()
        Me.btn24 = New System.Windows.Forms.Button()
        Me.btn25 = New System.Windows.Forms.Button()
        Me.btn31 = New System.Windows.Forms.Button()
        Me.btn32 = New System.Windows.Forms.Button()
        Me.btn33 = New System.Windows.Forms.Button()
        Me.btn34 = New System.Windows.Forms.Button()
        Me.btn35 = New System.Windows.Forms.Button()
        Me.btn16 = New System.Windows.Forms.Button()
        Me.btn17 = New System.Windows.Forms.Button()
        Me.btn18 = New System.Windows.Forms.Button()
        Me.btn19 = New System.Windows.Forms.Button()
        Me.btn110 = New System.Windows.Forms.Button()
        Me.btn26 = New System.Windows.Forms.Button()
        Me.btn27 = New System.Windows.Forms.Button()
        Me.btn28 = New System.Windows.Forms.Button()
        Me.btn29 = New System.Windows.Forms.Button()
        Me.btn210 = New System.Windows.Forms.Button()
        Me.btn36 = New System.Windows.Forms.Button()
        Me.btn37 = New System.Windows.Forms.Button()
        Me.btn38 = New System.Windows.Forms.Button()
        Me.btn39 = New System.Windows.Forms.Button()
        Me.btn310 = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(29, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(149, 43)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Ticket Booth" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Your Total is:"
        '
        'Label2
        '
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(187, 580)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(531, 56)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "The Stage"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Font = New System.Drawing.Font("Microsoft Sans Serif", 14.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(391, 294)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(60, 223)
        Me.Label3.TabIndex = 2
        Me.Label3.Text = "A" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "I" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "S" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "L" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "E"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.lblCancel)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.lblTotal)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(315, 26)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(270, 120)
        Me.Panel1.TabIndex = 3
        '
        'lblCancel
        '
        Me.lblCancel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCancel.Location = New System.Drawing.Point(178, 74)
        Me.lblCancel.Name = "lblCancel"
        Me.lblCancel.Size = New System.Drawing.Size(74, 23)
        Me.lblCancel.TabIndex = 3
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(16, 77)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(151, 20)
        Me.Label4.TabIndex = 2
        Me.Label4.Text = "No. of cancellations:"
        '
        'lblTotal
        '
        Me.lblTotal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblTotal.Location = New System.Drawing.Point(159, 32)
        Me.lblTotal.Name = "lblTotal"
        Me.lblTotal.Size = New System.Drawing.Size(93, 23)
        Me.lblTotal.TabIndex = 1
        '
        'btn11
        '
        Me.btn11.BackColor = System.Drawing.Color.White
        Me.btn11.Location = New System.Drawing.Point(84, 321)
        Me.btn11.Name = "btn11"
        Me.btn11.Size = New System.Drawing.Size(35, 35)
        Me.btn11.TabIndex = 4
        Me.btn11.Text = "5"
        Me.btn11.UseVisualStyleBackColor = False
        '
        'btn12
        '
        Me.btn12.BackColor = System.Drawing.Color.White
        Me.btn12.Location = New System.Drawing.Point(130, 320)
        Me.btn12.Name = "btn12"
        Me.btn12.Size = New System.Drawing.Size(35, 35)
        Me.btn12.TabIndex = 5
        Me.btn12.Text = "4"
        Me.btn12.UseVisualStyleBackColor = False
        '
        'btn13
        '
        Me.btn13.BackColor = System.Drawing.Color.White
        Me.btn13.Location = New System.Drawing.Point(193, 320)
        Me.btn13.Name = "btn13"
        Me.btn13.Size = New System.Drawing.Size(35, 35)
        Me.btn13.TabIndex = 6
        Me.btn13.Text = "3"
        Me.btn13.UseVisualStyleBackColor = False
        '
        'btn14
        '
        Me.btn14.BackColor = System.Drawing.Color.White
        Me.btn14.Location = New System.Drawing.Point(257, 322)
        Me.btn14.Name = "btn14"
        Me.btn14.Size = New System.Drawing.Size(35, 35)
        Me.btn14.TabIndex = 7
        Me.btn14.Text = "2"
        Me.btn14.UseVisualStyleBackColor = False
        '
        'btn15
        '
        Me.btn15.BackColor = System.Drawing.Color.White
        Me.btn15.Location = New System.Drawing.Point(315, 321)
        Me.btn15.Name = "btn15"
        Me.btn15.Size = New System.Drawing.Size(35, 35)
        Me.btn15.TabIndex = 8
        Me.btn15.Text = "1"
        Me.btn15.UseVisualStyleBackColor = False
        '
        'btn21
        '
        Me.btn21.BackColor = System.Drawing.Color.White
        Me.btn21.Location = New System.Drawing.Point(84, 379)
        Me.btn21.Name = "btn21"
        Me.btn21.Size = New System.Drawing.Size(35, 35)
        Me.btn21.TabIndex = 9
        Me.btn21.Text = "5"
        Me.btn21.UseVisualStyleBackColor = False
        '
        'btn22
        '
        Me.btn22.BackColor = System.Drawing.Color.White
        Me.btn22.Location = New System.Drawing.Point(130, 379)
        Me.btn22.Name = "btn22"
        Me.btn22.Size = New System.Drawing.Size(35, 35)
        Me.btn22.TabIndex = 10
        Me.btn22.Text = "4"
        Me.btn22.UseVisualStyleBackColor = False
        '
        'btn23
        '
        Me.btn23.BackColor = System.Drawing.Color.White
        Me.btn23.Location = New System.Drawing.Point(193, 379)
        Me.btn23.Name = "btn23"
        Me.btn23.Size = New System.Drawing.Size(35, 35)
        Me.btn23.TabIndex = 11
        Me.btn23.Text = "3"
        Me.btn23.UseVisualStyleBackColor = False
        '
        'btn24
        '
        Me.btn24.BackColor = System.Drawing.Color.White
        Me.btn24.Location = New System.Drawing.Point(257, 379)
        Me.btn24.Name = "btn24"
        Me.btn24.Size = New System.Drawing.Size(35, 35)
        Me.btn24.TabIndex = 12
        Me.btn24.Text = "2"
        Me.btn24.UseVisualStyleBackColor = False
        '
        'btn25
        '
        Me.btn25.BackColor = System.Drawing.Color.White
        Me.btn25.Location = New System.Drawing.Point(315, 379)
        Me.btn25.Name = "btn25"
        Me.btn25.Size = New System.Drawing.Size(35, 35)
        Me.btn25.TabIndex = 13
        Me.btn25.Text = "1"
        Me.btn25.UseVisualStyleBackColor = False
        '
        'btn31
        '
        Me.btn31.BackColor = System.Drawing.Color.White
        Me.btn31.Location = New System.Drawing.Point(84, 442)
        Me.btn31.Name = "btn31"
        Me.btn31.Size = New System.Drawing.Size(35, 35)
        Me.btn31.TabIndex = 14
        Me.btn31.Text = "5"
        Me.btn31.UseVisualStyleBackColor = False
        '
        'btn32
        '
        Me.btn32.BackColor = System.Drawing.Color.White
        Me.btn32.Location = New System.Drawing.Point(130, 442)
        Me.btn32.Name = "btn32"
        Me.btn32.Size = New System.Drawing.Size(35, 35)
        Me.btn32.TabIndex = 15
        Me.btn32.Text = "4"
        Me.btn32.UseVisualStyleBackColor = False
        '
        'btn33
        '
        Me.btn33.BackColor = System.Drawing.Color.White
        Me.btn33.Location = New System.Drawing.Point(193, 442)
        Me.btn33.Name = "btn33"
        Me.btn33.Size = New System.Drawing.Size(35, 35)
        Me.btn33.TabIndex = 16
        Me.btn33.Text = "3"
        Me.btn33.UseVisualStyleBackColor = False
        '
        'btn34
        '
        Me.btn34.BackColor = System.Drawing.Color.White
        Me.btn34.Location = New System.Drawing.Point(257, 442)
        Me.btn34.Name = "btn34"
        Me.btn34.Size = New System.Drawing.Size(35, 35)
        Me.btn34.TabIndex = 17
        Me.btn34.Text = "2"
        Me.btn34.UseVisualStyleBackColor = False
        '
        'btn35
        '
        Me.btn35.BackColor = System.Drawing.Color.White
        Me.btn35.Location = New System.Drawing.Point(315, 442)
        Me.btn35.Name = "btn35"
        Me.btn35.Size = New System.Drawing.Size(35, 35)
        Me.btn35.TabIndex = 18
        Me.btn35.Text = "1"
        Me.btn35.UseVisualStyleBackColor = False
        '
        'btn16
        '
        Me.btn16.BackColor = System.Drawing.Color.White
        Me.btn16.Location = New System.Drawing.Point(493, 322)
        Me.btn16.Name = "btn16"
        Me.btn16.Size = New System.Drawing.Size(35, 35)
        Me.btn16.TabIndex = 19
        Me.btn16.Text = "1"
        Me.btn16.UseVisualStyleBackColor = False
        '
        'btn17
        '
        Me.btn17.BackColor = System.Drawing.Color.White
        Me.btn17.Location = New System.Drawing.Point(550, 322)
        Me.btn17.Name = "btn17"
        Me.btn17.Size = New System.Drawing.Size(35, 35)
        Me.btn17.TabIndex = 20
        Me.btn17.Text = "2"
        Me.btn17.UseVisualStyleBackColor = False
        '
        'btn18
        '
        Me.btn18.BackColor = System.Drawing.Color.White
        Me.btn18.Location = New System.Drawing.Point(609, 322)
        Me.btn18.Name = "btn18"
        Me.btn18.Size = New System.Drawing.Size(35, 35)
        Me.btn18.TabIndex = 21
        Me.btn18.Text = "3"
        Me.btn18.UseVisualStyleBackColor = False
        '
        'btn19
        '
        Me.btn19.BackColor = System.Drawing.Color.White
        Me.btn19.Location = New System.Drawing.Point(674, 322)
        Me.btn19.Name = "btn19"
        Me.btn19.Size = New System.Drawing.Size(35, 35)
        Me.btn19.TabIndex = 22
        Me.btn19.Text = "4"
        Me.btn19.UseVisualStyleBackColor = False
        '
        'btn110
        '
        Me.btn110.BackColor = System.Drawing.Color.White
        Me.btn110.Location = New System.Drawing.Point(734, 322)
        Me.btn110.Name = "btn110"
        Me.btn110.Size = New System.Drawing.Size(35, 35)
        Me.btn110.TabIndex = 23
        Me.btn110.Text = "5"
        Me.btn110.UseVisualStyleBackColor = False
        '
        'btn26
        '
        Me.btn26.BackColor = System.Drawing.Color.White
        Me.btn26.Location = New System.Drawing.Point(493, 379)
        Me.btn26.Name = "btn26"
        Me.btn26.Size = New System.Drawing.Size(35, 35)
        Me.btn26.TabIndex = 24
        Me.btn26.Text = "1"
        Me.btn26.UseVisualStyleBackColor = False
        '
        'btn27
        '
        Me.btn27.BackColor = System.Drawing.Color.White
        Me.btn27.Location = New System.Drawing.Point(550, 379)
        Me.btn27.Name = "btn27"
        Me.btn27.Size = New System.Drawing.Size(35, 35)
        Me.btn27.TabIndex = 25
        Me.btn27.Text = "2"
        Me.btn27.UseVisualStyleBackColor = False
        '
        'btn28
        '
        Me.btn28.BackColor = System.Drawing.Color.White
        Me.btn28.Location = New System.Drawing.Point(609, 379)
        Me.btn28.Name = "btn28"
        Me.btn28.Size = New System.Drawing.Size(35, 35)
        Me.btn28.TabIndex = 26
        Me.btn28.Text = "3"
        Me.btn28.UseVisualStyleBackColor = False
        '
        'btn29
        '
        Me.btn29.BackColor = System.Drawing.Color.White
        Me.btn29.Location = New System.Drawing.Point(674, 379)
        Me.btn29.Name = "btn29"
        Me.btn29.Size = New System.Drawing.Size(35, 35)
        Me.btn29.TabIndex = 27
        Me.btn29.Text = "4"
        Me.btn29.UseVisualStyleBackColor = False
        '
        'btn210
        '
        Me.btn210.BackColor = System.Drawing.Color.White
        Me.btn210.Location = New System.Drawing.Point(734, 379)
        Me.btn210.Name = "btn210"
        Me.btn210.Size = New System.Drawing.Size(35, 35)
        Me.btn210.TabIndex = 28
        Me.btn210.Text = "5"
        Me.btn210.UseVisualStyleBackColor = False
        '
        'btn36
        '
        Me.btn36.BackColor = System.Drawing.Color.White
        Me.btn36.Location = New System.Drawing.Point(493, 442)
        Me.btn36.Name = "btn36"
        Me.btn36.Size = New System.Drawing.Size(35, 35)
        Me.btn36.TabIndex = 29
        Me.btn36.Text = "1"
        Me.btn36.UseVisualStyleBackColor = False
        '
        'btn37
        '
        Me.btn37.BackColor = System.Drawing.Color.White
        Me.btn37.Location = New System.Drawing.Point(550, 442)
        Me.btn37.Name = "btn37"
        Me.btn37.Size = New System.Drawing.Size(35, 35)
        Me.btn37.TabIndex = 30
        Me.btn37.Text = "2"
        Me.btn37.UseVisualStyleBackColor = False
        '
        'btn38
        '
        Me.btn38.BackColor = System.Drawing.Color.White
        Me.btn38.Location = New System.Drawing.Point(609, 442)
        Me.btn38.Name = "btn38"
        Me.btn38.Size = New System.Drawing.Size(35, 35)
        Me.btn38.TabIndex = 31
        Me.btn38.Text = "3"
        Me.btn38.UseVisualStyleBackColor = False
        '
        'btn39
        '
        Me.btn39.BackColor = System.Drawing.Color.White
        Me.btn39.Location = New System.Drawing.Point(674, 442)
        Me.btn39.Name = "btn39"
        Me.btn39.Size = New System.Drawing.Size(35, 35)
        Me.btn39.TabIndex = 32
        Me.btn39.Text = "4"
        Me.btn39.UseVisualStyleBackColor = False
        '
        'btn310
        '
        Me.btn310.BackColor = System.Drawing.Color.White
        Me.btn310.Location = New System.Drawing.Point(734, 442)
        Me.btn310.Name = "btn310"
        Me.btn310.Size = New System.Drawing.Size(35, 35)
        Me.btn310.TabIndex = 33
        Me.btn310.Text = "5"
        Me.btn310.UseVisualStyleBackColor = False
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(587, 192)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(75, 43)
        Me.btnClear.TabIndex = 35
        Me.btnClear.Text = "Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(283, 187)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(67, 52)
        Me.btnExit.TabIndex = 36
        Me.btnExit.Text = "Exit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(18, 332)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(40, 13)
        Me.Label5.TabIndex = 37
        Me.Label5.Text = "ROW1"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(20, 390)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(40, 13)
        Me.Label6.TabIndex = 38
        Me.Label6.Text = "ROW2"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(20, 453)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(40, 13)
        Me.Label7.TabIndex = 39
        Me.Label7.Text = "ROW3"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(910, 677)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.btnExit)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btn310)
        Me.Controls.Add(Me.btn39)
        Me.Controls.Add(Me.btn38)
        Me.Controls.Add(Me.btn37)
        Me.Controls.Add(Me.btn36)
        Me.Controls.Add(Me.btn210)
        Me.Controls.Add(Me.btn29)
        Me.Controls.Add(Me.btn28)
        Me.Controls.Add(Me.btn27)
        Me.Controls.Add(Me.btn26)
        Me.Controls.Add(Me.btn110)
        Me.Controls.Add(Me.btn19)
        Me.Controls.Add(Me.btn18)
        Me.Controls.Add(Me.btn17)
        Me.Controls.Add(Me.btn16)
        Me.Controls.Add(Me.btn35)
        Me.Controls.Add(Me.btn34)
        Me.Controls.Add(Me.btn33)
        Me.Controls.Add(Me.btn32)
        Me.Controls.Add(Me.btn31)
        Me.Controls.Add(Me.btn25)
        Me.Controls.Add(Me.btn24)
        Me.Controls.Add(Me.btn23)
        Me.Controls.Add(Me.btn22)
        Me.Controls.Add(Me.btn21)
        Me.Controls.Add(Me.btn15)
        Me.Controls.Add(Me.btn14)
        Me.Controls.Add(Me.btn13)
        Me.Controls.Add(Me.btn12)
        Me.Controls.Add(Me.btn11)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Form1"
        Me.Text = "as"
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents lblTotal As System.Windows.Forms.Label
    Friend WithEvents btn11 As System.Windows.Forms.Button
    Friend WithEvents btn12 As System.Windows.Forms.Button
    Friend WithEvents btn13 As System.Windows.Forms.Button
    Friend WithEvents btn14 As System.Windows.Forms.Button
    Friend WithEvents btn15 As System.Windows.Forms.Button
    Friend WithEvents btn21 As System.Windows.Forms.Button
    Friend WithEvents btn22 As System.Windows.Forms.Button
    Friend WithEvents btn23 As System.Windows.Forms.Button
    Friend WithEvents btn24 As System.Windows.Forms.Button
    Friend WithEvents btn25 As System.Windows.Forms.Button
    Friend WithEvents btn31 As System.Windows.Forms.Button
    Friend WithEvents btn32 As System.Windows.Forms.Button
    Friend WithEvents btn33 As System.Windows.Forms.Button
    Friend WithEvents btn34 As System.Windows.Forms.Button
    Friend WithEvents btn35 As System.Windows.Forms.Button
    Friend WithEvents btn16 As System.Windows.Forms.Button
    Friend WithEvents btn17 As System.Windows.Forms.Button
    Friend WithEvents btn18 As System.Windows.Forms.Button
    Friend WithEvents btn19 As System.Windows.Forms.Button
    Friend WithEvents btn110 As System.Windows.Forms.Button
    Friend WithEvents btn26 As System.Windows.Forms.Button
    Friend WithEvents btn27 As System.Windows.Forms.Button
    Friend WithEvents btn28 As System.Windows.Forms.Button
    Friend WithEvents btn29 As System.Windows.Forms.Button
    Friend WithEvents btn210 As System.Windows.Forms.Button
    Friend WithEvents btn36 As System.Windows.Forms.Button
    Friend WithEvents btn37 As System.Windows.Forms.Button
    Friend WithEvents btn38 As System.Windows.Forms.Button
    Friend WithEvents btn39 As System.Windows.Forms.Button
    Friend WithEvents btn310 As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents lblCancel As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label

End Class
